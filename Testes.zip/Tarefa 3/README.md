Seu objetivo é codificar um design e uma interação, que estão dentro da pasta /design do arquivo a seguir, através de uma imagem e um vídeo explicando a interação
=============================================

* Use o SASS para a geração do CSS, não pode usar nenhum framework ou library.