Sua tafera é gerar o codigo HTML e CSS do layout (dentro da pasta psd)
=======================================================================

* Use o SASS para a geração do CSS e o HTML precisa ser semantico, não pode usar nenhum framework ou library.