Como você validaria um campo de e-mail para ele não estar vazio e ser um e-mail válido?
=======================================================================================

* Escreva o código HTML/JS para esta questão, não pode usar a validação do HTML5 (type email).